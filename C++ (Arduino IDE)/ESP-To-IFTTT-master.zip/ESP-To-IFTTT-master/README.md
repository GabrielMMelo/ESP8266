# ESP-To-IFTTT
Arduino sketch for sending sensor data to IFTTT
